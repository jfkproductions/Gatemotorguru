<?php
    $city = "Boksburg";
    include "include/gate-motors-city.php";
?>