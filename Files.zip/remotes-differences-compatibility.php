<?php
    $article = "remotes-differences-compatibility.php";
    include "include/article-page.php";
?>
