<?php
    $article = "slim-slider-repairs-spares.php";
    include "include/article-page.php";
?>
