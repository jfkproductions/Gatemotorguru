<?php
    $city = "Roodepoort";
    include "include/gate-motors-city.php";
?>