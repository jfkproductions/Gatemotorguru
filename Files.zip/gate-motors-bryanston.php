<?php
    $city = "Bryanston";
    include "include/gate-motors-city.php";
?>