<?php
    $city = "Fourways";
    include "include/gate-motors-city.php";
?>