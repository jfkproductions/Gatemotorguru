<?php
    $province = "Cape";
    include "include/gate-motors-province.php";
?>