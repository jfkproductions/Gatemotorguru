<?php
    $city = "Richards Bay";
    include "include/gate-motors-city.php";
?>