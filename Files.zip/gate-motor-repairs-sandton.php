<?php
    $city = "Sandton";
    include "include/gate-motor-repairs-city.php";
?>
