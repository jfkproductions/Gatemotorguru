<?php
    $guruName    = "Vernon";
    $guruCell    = "072 396 8129";
    $guruArea    = "Centurion";
    $partnerInfo = "include/vernon-cia-info.php";
    include "include/guru-page.php";
?>
