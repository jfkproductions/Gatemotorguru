<?php
    $brand = "gemini";
    include "include/brand-gate-motor-repairs.php";
?>
