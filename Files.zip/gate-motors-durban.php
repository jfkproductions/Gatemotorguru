<?php
    $province = "Durban";
    include "include/gate-motors-province.php";
?>