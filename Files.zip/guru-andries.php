<?php
    $guruName    = "Andries Malan";
    $guruCell    = "083 327 2921";
    $guruArea    = "Pretora-Johannesburg";
    include "include/guru-page.php";
?>
