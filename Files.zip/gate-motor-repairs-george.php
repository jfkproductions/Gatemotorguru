<?php
    $city = "George";
    include "include/gate-motor-repairs-city.php";
?>
