<?php
    $city = "Boksburg";
    include "include/gate-motor-repairs-city.php";
?>
