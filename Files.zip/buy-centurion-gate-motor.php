<?php
    $brand="centurion";
    include "include/buy-brand-gate-motor.php";

?>
