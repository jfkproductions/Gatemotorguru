<?php
    $city = "Port Elizabeth";
    include "include/gate-motors-city.php";
?>