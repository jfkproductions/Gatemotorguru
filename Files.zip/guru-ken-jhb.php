<?php
    $guruName    = "Ken";
    $guruCell    = "076 858 8087";
    $guruArea    = "Northern Jhb";
    $partnerInfo = "include/ken-jhb-info.php";
    $newLayout   = 1;
    $guruInactive = 1;
    $guruPic     = "ken-big.jpg";
    include "include/guru-page.php";
?>