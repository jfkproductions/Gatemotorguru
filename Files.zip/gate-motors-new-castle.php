<?php
    $city = "New Castle";
    include "include/gate-motors-city.php";
?>