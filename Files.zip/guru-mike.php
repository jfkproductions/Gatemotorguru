<?php
    $guruName    = "Mike";
    $guruCell    = "083 308 5748";
    $guruArea    = "Jhb,West Rand,Krugersdorp";
    $partnerInfo = "include/mike-jhb-info.php";
    $newLayout   = 1;
    $guruPic     = "mike-big.jpg";
    include "include/guru-page.php";
?>