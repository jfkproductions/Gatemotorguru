<?php
    $city = "Benoni";
    include "include/gate-motors-city.php";
?>