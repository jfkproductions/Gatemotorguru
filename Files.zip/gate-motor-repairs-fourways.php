<?php
    $city = "Fourways";
    include "include/gate-motor-repairs-city.php";
?>
