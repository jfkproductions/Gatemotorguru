<?php
    $city = "Randburg";
    include "include/gate-motors-city.php";
?>