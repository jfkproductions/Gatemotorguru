<?php
    $guruName    = "Juan";
    $guruCell    = "079 887 6459";
    $guruArea    = "Pretoria,  Midrand, Centurion, Alberton, Sandton";
    $partnerInfo = "include/juan-jhb-info.php";
    $newLayout   = 1;
    $guruPic     = "juan-big.jpg";
    include "include/guru-page.php";
?>