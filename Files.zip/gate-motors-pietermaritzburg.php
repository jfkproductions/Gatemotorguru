<?php
    $city = "Pietermaritzburg";
    include "include/gate-motors-city.php";
?>