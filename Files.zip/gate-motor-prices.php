<?php 
include_once "include/globalsettings.php";
include_once "include/areas.php";
include_once "include/snippets.php";

$pageTitle = "Gate Motor Prices from Gate Motor Guru";
$metaTitle = "Gate Motor Prices Centurion, Gemini, Hansa, - motor only price or fully installed.";
$metaDescription = "Gate Motor Prices Centurion, Gemini, Hansa, - motor only price or fully installed.";
$metaKeywords = "gate motor,gate motors,gate automation";

include_once "include/header.php";
?>

<div style="float:left">
    <h1>Gate Motor Prices</h1>
    <div style="width:495px;text-align: center; padding:10px">
        <div style="text-align:left">
              <br/>

                <span style="text-transform:uppercase">
                    <strong style="font-size:200%">Gate Motor Prices</strong> for motor-only (delivered) or fully installed.</span>
                <br/>
                <br/>
        </div>
    </div>
</div>
<div style="clear:both"></div>
<br/>

<h2>Centurion Gate Motor Prices</h2>
<div style="border-style:solid;border-width: 1px">
<table>
    <tr>
        <td>
            <h3>Centurion D5 Gate Motor</h3>
            <ul>
                <li>Our most popular motor.</li>
                <li>Ideal for all home and light commercial use</li>
            </ul>
        </td>
        <td>
            [picture goes here]<br/>
            <a>Detailed information about the Centurion D5 Gate Motor - Click Here</a>
        </td>
        <td>
            <strong>Price for Centurion D5 Gate Motor</strong><br/>
              Motor Only Delivered (Most areas): R 3600.00 VAT Included<br/>
              Motor including expert installation: R 4750 - 5800 (Depending on area & requirements).<br/>
              <button> Buy Now <br/> Or Enquire</button>
        </td>
    </tr>
</table>
</div>








<br/>
<br/>
<?php include "include/footer.php"; ?>

