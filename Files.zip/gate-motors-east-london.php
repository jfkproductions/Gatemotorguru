<?php
    $city = "East London";
    include "include/gate-motors-city.php";
?>