<?php
    $guruName    = "Justin Alberts";
    $guruCell    = "072 125 7907";
    $guruArea    = "Pretoria,Centurion,Midrand";
    $guruPic     = "justin-big.jpg";
    $partnerInfo = "include/justin-alberts-info.php";
    $newLayout   = 1;
    include "include/guru-page.php";
?>
