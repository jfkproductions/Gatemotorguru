<?php
    $article = "program-centurion.php";
    include "include/article-page.php";
?>
