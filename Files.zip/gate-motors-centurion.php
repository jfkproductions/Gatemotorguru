<?php
    $city = "Centurion";
    include "include/gate-motors-city.php";
?>