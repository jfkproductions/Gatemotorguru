<?php
    $guruName    = "Kevin";
    $guruCell    = "079 754 1889";
    $guruOffice  = "012 997 0280";
    $guruArea    = "Pretoria-Midrand";
    $partnerInfo = "include/kevin-ck-info.php";
    $newLayout   = 1;
    $guruInactive = 1;
    $guruPic     = "kevin-big.jpg";
    include "include/guru-page.php";
?>
