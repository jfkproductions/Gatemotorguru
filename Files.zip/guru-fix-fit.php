<?php
    $guruName    = "Wimpie Pretorius";
    $guruCell    = "083 708 2766";
    $guruArea    = "Joburg All Areas";
    $partnerInfo = "include/wimpie-pretorius-info.php";
    include "include/guru-page.php";
?>
