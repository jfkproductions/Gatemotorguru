<?php
    $city = "Johannesburg";
    include "include/gate-motors-city.php";
?>