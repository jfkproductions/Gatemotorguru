<?php
    $city = "Umshlanga";
    include "include/gate-motors-city.php";
?>