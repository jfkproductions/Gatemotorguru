<?php
    $city = "Midrand";
    include "include/gate-motors-city.php";
?>