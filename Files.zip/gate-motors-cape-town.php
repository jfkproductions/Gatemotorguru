<?php
    $city = "Cape Town";
    include "include/gate-motors-city.php";
?>