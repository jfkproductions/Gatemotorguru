<?php
    $city = "Pietermaritzburg";
    include "include/gate-motor-repairs-city.php";
?>
