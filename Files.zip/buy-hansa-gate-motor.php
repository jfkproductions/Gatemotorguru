<?php
    $brand="hansa";
    include "include/buy-brand-gate-motor.php";

?>
