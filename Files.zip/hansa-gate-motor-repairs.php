<?php
    $brand = "hansa";
    include "include/brand-gate-motor-repairs.php";
?>
