<?php
    $article = "super-500-parts-repairs.php";
    include "include/article-page.php";
?>
