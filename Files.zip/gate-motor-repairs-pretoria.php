<?php
    $city = "Pretoria";
    include "include/gate-motor-repairs-city.php";
?>
