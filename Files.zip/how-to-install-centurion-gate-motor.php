<?php
    $article = "install-centurion-dseries.php";
    include "include/article-page.php";
?>
