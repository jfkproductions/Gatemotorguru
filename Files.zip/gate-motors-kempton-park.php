<?php
    $city = "Kempton Park";
    include "include/gate-motors-city.php";
?>