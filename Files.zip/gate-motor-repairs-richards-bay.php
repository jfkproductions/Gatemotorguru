<?php
    $city = "Richards Bay";
    include "include/gate-motor-repairs-city.php";
?>
