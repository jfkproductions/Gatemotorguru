<?php
    $guruName    = "Allen Chenik";
    $guruCell    = "082 413 5461";
    $guruArea    = "Kempton Park - Benoni";
    $partnerInfo = "include/allen-chenik-info.php";
    $guruPic     = "allen-big.jpg";
    $newLayout   = 1;
    include "include/guru-page.php";
?>
