<?php
    $city = "Cape Town";
    include "include/gate-motor-repairs-city.php";
?>
