<?php
    $brand="gemini";
    include "include/buy-brand-gate-motor.php";

?>
