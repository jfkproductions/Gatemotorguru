<?php
    $guruName    = "Warren \"Mr Reliable\"";
    $guruCell    = "084 4007875";
    $guruArea    = "Durban";
    $partnerInfo = "include/warren-durban-info.php";
    include "include/guru-page.php";
?>
