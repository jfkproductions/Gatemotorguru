<?php
    $city = "East London";
    include "include/gate-motor-repairs-city.php";
?>
