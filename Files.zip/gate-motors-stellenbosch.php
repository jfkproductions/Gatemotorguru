<?php
    $city = "Stellenbosch";
    include "include/gate-motors-city.php";
?>