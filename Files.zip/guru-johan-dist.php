<?php
    $guruName    = "Johan";
    $guruCell    = "083 267 5098";
    $guruArea    = "Randburg,Roodepoort";
    $partnerInfo = "include/johan-dist-info.php";
    $newLayout   = 1;
    $guruPic     = "johan-dss-big.jpg";
    include "include/guru-page.php";
?>
