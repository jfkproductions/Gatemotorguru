<?php
    $city = "George";
    include "include/gate-motors-city.php";
?>