<?php
    $city = "Pretoria";
    include "include/gate-motors-city.php";
?>