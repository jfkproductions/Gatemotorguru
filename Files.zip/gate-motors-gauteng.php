<?php
    $province = "Gauteng";
    include "include/gate-motors-province.php";
?>