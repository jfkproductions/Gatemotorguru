<?php
    $city = "Johannesburg";
    include "include/gate-motor-repairs-city.php";
?>
