<?php
    $brand="centurion";
    $extraInfo = "info-centurion-installation.php";
    
    include "include/brand-gate-motor-installation.php";
?>
