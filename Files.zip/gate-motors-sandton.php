<?php
    $city = "Sandton";
    include "include/gate-motors-city.php";
?>