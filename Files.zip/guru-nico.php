<?php
    $guruName    = "Nico";
    $guruCell    = "072 994 2380";
    $guruArea    = "East Rand,Kempton,Bedfordview,Germiston,Primrose";
    $partnerInfo = "include/nico-jhb-info.php";
    $newLayout   = 1;
    $guruPic     = "nico-big.jpg";
    include "include/guru-page.php";
?>