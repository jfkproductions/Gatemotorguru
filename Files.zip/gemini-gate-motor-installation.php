<?php
    $brand="gemini";
    include "include/brand-gate-motor-installation.php";
?>
