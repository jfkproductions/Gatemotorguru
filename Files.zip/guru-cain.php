<?php
// Permanent redirection
header("HTTP/1.1 301 Moved Permanently");
header("Location: http://www.gatemotorguru.co.za/guru-ken-jhb.php");
exit();
?>