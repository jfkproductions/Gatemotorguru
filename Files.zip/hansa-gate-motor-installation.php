<?php
    $brand="hansa";
    include "include/brand-gate-motor-installation.php";
?>
