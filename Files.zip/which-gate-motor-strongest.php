<?php
    $article = "which-gate-motor-strongest.php";
    include "include/article-page.php";
?>
